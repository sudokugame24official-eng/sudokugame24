import {
  Injectable,
  BadRequestException,
  Logger,
  ForbiddenException,
  NotFoundException,
} from '@nestjs/common';
import { prisma, PerkType, CoinTransactionType } from '@repo/database';
import { CoinLedgerService } from '../coin-ledger/coin-ledger.service';
import { trackEvent } from '../analytics/track-event';
import { FeatureFlagService } from '../config/feature-flag.service';
import Stripe from 'stripe';

// Real-money coin packs (can be moved to DB later if needed, but usually fixed SKU)
const COIN_PACKS = [
  {
    id: 'pack_1',
    name: 'Pack Débutant',
    coins: 500,
    priceEur: 4.99,
    image: '/images/coins_small.png',
  },
  {
    id: 'pack_2',
    name: 'Pack Populaire',
    coins: 1500,
    priceEur: 9.99,
    image: '/images/coins_medium.png',
    popular: true,
  },
  {
    id: 'pack_3',
    name: 'Trésor du Maître',
    coins: 4000,
    priceEur: 19.99,
    image: '/images/coins_large.png',
  },
];

@Injectable()
export class ShopService {
  private readonly logger = new Logger(ShopService.name);
  private stripe: Stripe | null = null;

  constructor(
    private readonly coinLedger: CoinLedgerService,
    private readonly featureFlags: FeatureFlagService,
  ) {}

  /**
   * Lazy Stripe client. No dummy fallback key: if payments are requested but
   * STRIPE_SECRET_KEY is not configured, we fail fast instead of silently
   * talking to Stripe with a bogus key.
   */
  private getStripe(): Stripe {
    if (!this.stripe) {
      if (!process.env.STRIPE_SECRET_KEY) {
        throw new ForbiddenException(
          'Les paiements ne sont pas configurés (STRIPE_SECRET_KEY manquante).',
        );
      }
      this.stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {});
    }
    return this.stripe;
  }

  /**
   * P1-H: server-authoritative verification for a checkout session.
   * The WEB BROWSER can trigger this check after redirect, but only the
   * server talks to Stripe: coins are credited only if Stripe itself says
   * the session is paid. Idempotent (purchase claim + ledger key), so it is
   * a safe catch-up path when the webhook is delayed or lost.
   */
  async verifyAndCompleteSession(userId: string, sessionId: string) {
    const isStripeEnabled =
      await this.featureFlags.isFeatureEnabled('ENABLE_STRIPE');
    if (!isStripeEnabled)
      throw new ForbiddenException('Les paiements sont désactivés.');

    const purchase = await prisma.purchase.findUnique({
      where: { stripeSessionId: sessionId },
    });
    if (!purchase) throw new NotFoundException('Achat introuvable.');
    if (purchase.userId !== userId)
      throw new ForbiddenException('Cet achat ne vous appartient pas.');

    if (purchase.status === 'COMPLETED') {
      return { status: 'COMPLETED', coinsGranted: purchase.coinsGranted };
    }

    // Retrieve the session FROM STRIPE (never trust client claims).
    const session =
      await this.getStripe().checkout.sessions.retrieve(sessionId);
    if (session.payment_status === 'paid') {
      await this.handleSuccessfulPayment(sessionId, `verify_${sessionId}`);
      const updated = await prisma.purchase.findUnique({
        where: { stripeSessionId: sessionId },
      });
      return {
        status: updated?.status ?? 'PENDING',
        coinsGranted: updated?.coinsGranted ?? 0,
      };
    }

    return { status: session.payment_status, coinsGranted: 0 };
  }

  getCoinPacks() {
    return COIN_PACKS;
  }

  async getProducts() {
    return prisma.shopProduct.findMany({
      where: { isActive: true },
      orderBy: { priceCoins: 'asc' },
    });
  }

  async getAllProductsAdmin() {
    return prisma.shopProduct.findMany({
      orderBy: { createdAt: 'desc' },
    });
  }

  async createProductAdmin(data: any) {
    return prisma.shopProduct.create({ data });
  }

  async updateProductAdmin(id: string, data: any) {
    return prisma.shopProduct.update({ where: { id }, data });
  }

  async deleteProductAdmin(id: string) {
    return prisma.shopProduct.delete({ where: { id } });
  }

  async getUserPerks(userId: string) {
    const perks = await prisma.userPerk.findMany({
      where: { userId },
    });
    const now = new Date();
    return perks.filter((p) => !p.expiresAt || p.expiresAt > now);
  }

  async createCheckoutSession(userId: string, packId: string) {
    const isStripeEnabled =
      await this.featureFlags.isFeatureEnabled('ENABLE_STRIPE');
    if (!isStripeEnabled)
      throw new ForbiddenException(
        'Les achats sont temporairement désactivés.',
      );

    const pack = COIN_PACKS.find((p) => p.id === packId);
    if (!pack) throw new BadRequestException('Pack introuvable');

    // P1-H: always a REAL Stripe session — no mock/local shortcut paths.
    let session;
    try {
      session = await this.getStripe().checkout.sessions.create({
        payment_method_types: ['card'],
        mode: 'payment',
        line_items: [
          {
            price_data: {
              currency: 'eur',
              product_data: { name: pack.name },
              unit_amount: Math.round(pack.priceEur * 100),
            },
            quantity: 1,
          },
        ],
        client_reference_id: userId,
        metadata: { packId: pack.id, coinsGranted: pack.coins },
        success_url: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/shop/checkout?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/shop?canceled=true`,
      });
    } catch (e) {
      this.logger.error('Erreur de création de session Stripe', e);
      throw new BadRequestException('Erreur de création de paiement');
    }

    await prisma.purchase.create({
      data: {
        userId,
        stripeSessionId: session.id,
        amount: pack.priceEur,
        currency: 'EUR',
        coinsGranted: pack.coins,
        status: 'PENDING',
      },
    });

    return { url: session.url };
  }

  async verifyStripeWebhook(
    signature: string,
    payload: Buffer,
  ): Promise<Stripe.Event> {
    // P1-H: signature verification is ALWAYS active — including test env.
    // No 'whsec_test' fallback: a missing secret must fail closed.
    const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!endpointSecret) {
      this.logger.error(
        'STRIPE_WEBHOOK_SECRET is not configured — refusing to process webhook',
      );
      throw new BadRequestException('Webhook non configuré');
    }
    try {
      return this.getStripe().webhooks.constructEvent(
        payload,
        signature,
        endpointSecret,
      );
    } catch (err) {
      this.logger.error(`⚠️  Webhook signature failed.`, err.message);
      throw new BadRequestException(`Webhook Error: ${err.message}`);
    }
  }

  async handleSuccessfulPayment(sessionId: string, stripeEventId?: string) {
    const isStripeEnabled =
      await this.featureFlags.isFeatureEnabled('ENABLE_STRIPE');
    if (!isStripeEnabled) return;

    const purchase = await prisma.purchase.findUnique({
      where: { stripeSessionId: sessionId },
    });
    if (!purchase || purchase.status === 'COMPLETED') return;

    try {
      const updatedPurchase = await prisma.purchase.updateMany({
        where: { id: purchase.id, status: 'PENDING' },
        data: { status: 'COMPLETED' },
      });

      if (updatedPurchase.count === 0) throw new Error('Already processed');

      void trackEvent({
        name: 'purchase',
        userId: purchase.userId,
        metadata: { coins: purchase.coinsGranted, sessionId },
      });

      await this.coinLedger.credit(
        purchase.userId,
        purchase.coinsGranted,
        CoinTransactionType.PURCHASE,
        'Stripe',
        sessionId,
        stripeEventId,
      );
    } catch (e) {
      // P0-G/D1: a failed completion must be terminal (FAILED), never reverted
      // to PENDING — reverting allowed a replayed webhook to double-credit.
      this.logger.error(`Paiement échoué pour ${sessionId}`, e);
      await prisma.purchase.updateMany({
        where: { stripeSessionId: sessionId, status: 'COMPLETED' },
        data: { status: 'FAILED' },
      });
    }
  }

  async buyProduct(userId: string, productId: string) {
    const isShopEnabled =
      await this.featureFlags.isFeatureEnabled('SHOP_ENABLED');
    if (!isShopEnabled)
      throw new ForbiddenException(
        'La boutique est temporairement désactivée.',
      );

    const product = await prisma.shopProduct.findUnique({
      where: { id: productId },
    });
    if (!product || !product.isActive)
      throw new BadRequestException('Produit indisponible.');

    // P1-E: enforce product constraints that used to be dead schema columns.
    const now = new Date();
    if (product.startDate && product.startDate > now) {
      throw new BadRequestException('Ce produit nest pas encore disponible.');
    }
    if (product.endDate && product.endDate < now) {
      throw new BadRequestException('Ce produit nest plus disponible.');
    }
    if (
      product.stock !== null &&
      product.stock !== undefined &&
      product.stock <= 0
    ) {
      throw new BadRequestException('Rupture de stock.');
    }
    if (product.maxPerUser !== null && product.maxPerUser !== undefined) {
      const bought = await prisma.coinTransaction.count({
        where: {
          userId,
          type: CoinTransactionType.SHOP_PURCHASE,
          referenceId: productId,
          amount: { lt: 0 }, // debits are purchases
        },
      });
      if (bought >= product.maxPerUser) {
        throw new BadRequestException(
          `Limite de ${product.maxPerUser} achat(s) par utilisateur atteinte.`,
        );
      }
    }

    let expiresAt: Date | null = null;
    if (product.durationDays) {
      expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + product.durationDays);
    }

    try {
      await prisma.$transaction(async (tx) => {
        // Debit coins. No Date.now()-based idempotency key: such keys never
        // deduplicate anything (every retry is a new key). The $transaction +
        // optimistic balance lock below is the actual double-spend guard, and
        // a retried purchase fairly delivers the product twice for two charges.
        await this.coinLedger.debit(
          userId,
          product.priceCoins,
          CoinTransactionType.SHOP_PURCHASE,
          'Shop',
          productId,
          undefined,
          undefined,
          tx,
        );

        // Apply Entitlement
        if (product.type === 'perk') {
          const existing = await tx.userPerk.findUnique({
            where: {
              userId_perkType: {
                userId,
                perkType: product.entitlement as PerkType,
              },
            },
          });

          if (existing && expiresAt) {
            const currentExp =
              existing.expiresAt && existing.expiresAt > new Date()
                ? existing.expiresAt
                : new Date();
            currentExp.setDate(currentExp.getDate() + product.durationDays!);
            await tx.userPerk.update({
              where: { id: existing.id },
              data: { expiresAt: currentExp },
            });
          } else {
            await tx.userPerk.create({
              data: {
                userId,
                perkType: product.entitlement as PerkType,
                expiresAt,
              },
            });
          }
        } else if (
          product.type === 'consumable' &&
          product.entitlement === 'EXTRA_HINTS'
        ) {
          await tx.profile.update({
            where: { userId },
            data: { hints: { increment: product.quantity || 1 } },
          });
        }

        // Decrement stock inside the same transaction (atomic with the debit).
        if (product.stock !== null && product.stock !== undefined) {
          const updated = await tx.shopProduct.updateMany({
            where: { id: product.id, stock: { gte: 1 } },
            data: { stock: { decrement: 1 } },
          });
          if (updated.count === 0) {
            throw new BadRequestException('Rupture de stock.');
          }
        }
      });
    } catch (error) {
      if (error instanceof BadRequestException)
        throw new BadRequestException('Fonds insuffisants');
      throw error;
    }

    return { success: true, message: 'Achat réussi !' };
  }

  async rewardAdWatch(userId: string) {
    const isRewardedAdsEnabled =
      await this.featureFlags.isFeatureEnabled('ADS_ENABLED');
    if (!isRewardedAdsEnabled)
      throw new ForbiddenException('Les publicités sont désactivées.');

    const REWARD_HINTS = 1;
    const REWARD_COINS = 10;
    // P0-G: daily cap — without it, spamming the (client-simulated) ad watch
    // was an unlimited coin faucet (a Date.now() idempotency key dedups nothing).
    const DAILY_CAP = parseInt(process.env.AD_REWARD_DAILY_CAP || '5', 10);

    const dayStart = new Date();
    dayStart.setUTCHours(0, 0, 0, 0);
    const claimedToday = await prisma.coinTransaction.count({
      where: {
        userId,
        type: CoinTransactionType.AD_REWARD,
        createdAt: { gte: dayStart },
      },
    });
    if (claimedToday >= DAILY_CAP) {
      throw new BadRequestException(
        'Limite quotidienne de récompenses publicitaires atteinte.',
      );
    }

    try {
      // Coins and hints atomically: one transaction, no partial reward.
      await prisma.$transaction(async (tx) => {
        await this.coinLedger.credit(
          userId,
          REWARD_COINS,
          CoinTransactionType.AD_REWARD,
          'AdSense_Rewarded',
          'ad_reward',
          undefined,
          undefined,
          tx,
        );
        await tx.profile.update({
          where: { userId },
          data: { hints: { increment: REWARD_HINTS } },
        });
      });
    } catch (e) {
      throw new BadRequestException('Could not reward at this time');
    }

    return {
      success: true,
      hintsGranted: REWARD_HINTS,
      coinsGranted: REWARD_COINS,
    };
  }
}
